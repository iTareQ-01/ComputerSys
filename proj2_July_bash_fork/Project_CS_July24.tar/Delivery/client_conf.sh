# Kindly, change the username after -l to your user before running.
# MAke sure the port you set is the same as you have set for the server.

./client_socket_bash -R 127.0.0.1 -p 4444 -l itareq
