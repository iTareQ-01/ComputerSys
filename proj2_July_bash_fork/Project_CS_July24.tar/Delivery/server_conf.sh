#You can change the port num to any you like (Well-Known).

./server_socket_bash 4444


